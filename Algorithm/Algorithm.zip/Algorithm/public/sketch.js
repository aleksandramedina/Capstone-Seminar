var socket;
var colorPicker;
var colorvalue;
var strokeValue;
var saturationcolor;
let stages = [0, 1, 2, 3, 4, 5, 6];
var xPoint;
var yPoint;
var ellipseHeight = 20;
var _instruction =0;
var interval = 5000;
var r;
var g;
var b;
var w = window.innerWidth;
var h = window.innerHeight;
var previousMillis = 0;
var xoff = 0.0;
var mode = 0;
var radius = 40;
var whichBuffer = 0;
var pg = [];
var otherPos;
var prevOther;
var otherMode=0;
var isTriggered = false;
var isMouseDragged = false;
var ranColor = 51;
var inst =0;


//
// function copyImage(src, dst) {
//     var n = src.length;
//     if (!dst || dst.length != n) dst = new src.constructor(n);
//     while (n--) dst[n] = src[n];
//     return dst;
// }


function setup() {
  createCanvas(w,h);
  colorMode(RGB, 255);
  background (51);
  pg[0] = createGraphics(w,h);
  pg[1] = createGraphics(w,h);
  pg[0].background(51);
  pg[1].background(51);
  otherPos = createVector(0,0);
  prevOther = createVector(0,0);
  // rectMode(CENTER);


  //eraser
  checkbox = createCheckbox('Eraser', false );
  checkbox.position(220, h-25);

  //slider for brush size
  slider = createSlider(5, 100, 30, 5);
  slider.position(320, h-25);

  //color picker
  colorPicker = createColorPicker(color('yellow'));
  colorPicker.position(30, h-30);


  socket = io.connect('http://localhost:3000')
  // socket = io.connect('http://9b9aaf69b57c.ngrok.io')
  socket.on('mouse', newDrawing);

}


function newDrawing(data){

  noStroke();
  fill(data.color);
  // stroke(data.stroke);

  if (data.instruction==0){
    ellipseHeight = data.slider;
    xPoint = data.x;
    yPoint = data.y;
    ellipse(xPoint, yPoint, data.slider, ellipseHeight);
  }
  else if (data.instruction==1){
    ellipseHeight = 1;
    xPoint = data.x;
    yPoint = data.y;
    ellipse(xPoint, yPoint, data.slider, ellipseHeight);
  }
  else if (data.instruction==2){
    ellipseHeight = data.slider;
    xPoint = data.y;
    yPoint = data.x;
    ellipse(xPoint, yPoint, data.slider, ellipseHeight);
  }else if (data.instruction==3){
    ellipseHeight = data.slider;
    xPoint = data.x;
    yPoint = data.y;
    ellipse(xPoint, yPoint, data.slider, ellipseHeight);
  }else if (data.instruction==4){
    ellipseHeight = data.slider;
    xPoint = data.x;
    yPoint = data.y;
    rect(xPoint, yPoint, data.slider, ellipseHeight);
  }else if (data.instruction==5){


    //just to simulate the sent position
    data.x = noise(frameCount * .001) * width;
    data.y = noise(frameCount * .003) * height;
    //to simulate the sent mode
    if (data.mode == 0) {
      push()
      stroke(255, 0, 0)
      rect(data.x, data.y, ellipseHeight, ellipseHeight);
      pop()
    } else if (data.mode == 1) {
      glitch(data.x, data.px, data.y, data.py)
    }
    //just to simulate the sent position
      data.px = data.x.copy();



  }else if (data.instruction==6){
    ellipseHeight = data.slider;
    xPoint = data.x;
    yPoint = data.y;
    ellipse(xPoint, yPoint, data.slider, ellipseHeight);
  }

  // console.log(millis());
  console.log(ellipseHeight);
  console.log(colorvalue);


}

// !!!!!!!
// the part where the data from one user is imported to the other user's machine

function mouseDragged(){

  isMouseDragged = true;

  var data = {
    x: mouseX,
    y: mouseY,
    color: colorvalue,
    slider: slider.value(),
    // stroke: strokeValue,
    instruction: _instruction,
    mode: mode,
    px: pmouseX,
    py: pmouseY

  }

socket.emit('mouse', data);

//Beginning of instructions
//Instruction 0: basic setting without any interruptions
//Instruction 1: ellipse height is set to 1 so the stroke becomes a inline
//Instruction 2: x and y axis are swapped

 if (data.instruction ==0){
   noStroke();

   if (checkbox.checked()){
     fill(51);
     colorvalue = 51;

   } else {
     fill(220);
     fill(colorPicker.value());
     colorvalue = colorPicker.value();
     console.log("Colorvalue: " + colorvalue);
   }


   ellipse(mouseX, mouseY, slider.value(), slider.value());
   ellipseHeight = slider.value();

   }

  else if (data.instruction ==1){
     noStroke();

     if (checkbox.checked()){
       fill(51);
       colorvalue = 51;

     } else {
       fill(220);
       fill(colorPicker.value());
       colorvalue = colorPicker.value();
     }

     ellipseHeight=1;

     ellipse(mouseX, mouseY, slider.value(), ellipseHeight);

   }  else if (data.instruction ==2){
          noStroke();

          if (checkbox.checked()){
            fill(51);
            colorvalue = 51;

          } else {
            fill(220);
            fill(colorPicker.value());
            colorvalue = colorPicker.value();
          }


          ellipse(mouseY, mouseX, slider.value(), slider.value());

        } else if (data.instruction ==3){

          noStroke();

          if (checkbox.checked()){
            fill(51);
            colorvalue = 51;

          } else {
            colorvalue = color(random (255),random (255),random (255)).toString('#rrggbbaa');
            fill(colorvalue);

            console.log("Color is: " + colorvalue);
          }

          ellipse(mouseX, mouseY, slider.value(), slider.value());
          ellipseHeight = slider.value();


        }  else if (data.instruction==4){
          noStroke();

          if (checkbox.checked()){
            fill(51);
            colorvalue = 51;

          } else {
            fill(220);
            fill(colorPicker.value());
            colorvalue = colorPicker.value();
          }


          rect(mouseX, mouseY, slider.value(), slider.value());
          ellipseHeight = slider.value();


        } else if (data.instruction==5){


          // rect(otherPos.x, otherPos.y, ellipseHeight, ellipseHeight);

          if (checkbox.checked()){
            fill(51);
            colorvalue = 51;

          } else {
            fill(220);
            fill(colorPicker.value());
            colorvalue = colorPicker.value();
          }
          ellipseHeight = slider.value();


  // time choice stuff
  let glitchTime = map(millis(), 0, 10000, 0, 1);
  glitchTime = constrain(glitchTime, 0, 1);

  // rand choice stuff
  let rand = random();
  if (rand <= .1 && glitchTime > .5) {
    mode = 1;
  } else if (rand > .1 && rand <= .2 && glitchTime > .2) {
    // some other mode here
  } else {
    mode = 0;
  }

  // regular drawing mode
  if (mode == 0) {
    rect(mouseX, mouseY, ellipseHeight, ellipseHeight);
  } else if (mode == 1) {
    glitch(mouseX, pmouseX, mouseY, pmouseY)
  }
}
  else if (data.instruction==6){
    noStroke();

    if (checkbox.checked()){
      fill(51);
      colorvalue = 51;

    } else {
      colorvalue = color(19,180,148).toString('#rrggbbaa');
      fill(colorvalue);

      console.log(colorvalue);
    }

    ellipse(mouseX, mouseY, slider.value(), slider.value());
    ellipseHeight = slider.value();

}


      //place to leave more options



        else {
       console.log("Other instruction found");
     }



    } // end of  mouseDragged()


function randomgenerator(){

    let s = second();
    console.log("s: " + s);

    if ((s%5==0 || s%5==1) && isMouseDragged == true){
      console.log("Mouse dragged: " + isMouseDragged);
      console.log("Is triggered: " + isTriggered);


      if (isTriggered == false){
        inst = random (stages);
        ranColor = color(random (255),random (255),random (255)).toString('#rrggbbaa');
        isTriggered = true;
      }
      fill(ranColor);
      _instruction = inst;
    }else {
      _instruction = 0;
      fill('rgba(230,230,230,0.7)');
      isTriggered = false;
      isMouseDragged = false;
    }

  // _instruction = 5;
  console.log("Instruction: "+ _instruction);
}

function saveWork(){
  saveCanvas(c, 'myDrawing', 'jpg');
}

function clearAll(){
  clear();
  background(51);
}

function glitch(mx, px, my, py) {
  loadPixels();
  let dir = createVector(parseInt(mx) - parseInt(px), parseInt(my) - parseInt(py));
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      if (dist(x, y, parseInt(mx), parseInt(my)) < radius) {
        let d = pixelDensity();
        let oldX = x - dir.x;
        let oldY = y - dir.y;
        for (let i = 0; i < d; i++) {
          for (let j = 0; j < d; j++) {
            if (oldX > 0 && oldX < width && oldY > 0 && oldY < height) {
              let oldPixelIndex = 4 * ((oldY * d + j) * width * d + (oldX * d + i));
              let index = 4 * ((y * d + j) * width * d + (x * d + i));
              pixels[index] = pixels[oldPixelIndex];
              pixels[index + 1] = pixels[oldPixelIndex + 1];
              pixels[index + 2] = pixels[oldPixelIndex + 2];
            }
          }
        }
      }
    }
  }
  updatePixels();
}
//
// function mouseClicked() {
//   otherMode = 1 - otherMode;
// }

function draw(){


randomgenerator();


  noStroke();
  // fill('rgba(230,230,230,0.7)');
  rect(0, h-45, w, 45);

  // fill('rgba(230,230,230,0.7)');
  rect(w-350, 0, w, h);
  // blockScroll();
  fill('black');
  textSize(16);
  text('Brush stroke', 460, h-17);
  text('Color picker', 100, h-17);

  textStyle(BOLD);
  text('Your task today: Draw a car', w-335, 30);

  textSize(14);
  textStyle(NORMAL);

  text('1. Pick a color that is good for sketching.', w-335, 80);
  text('2. Draw two circles next to each other on the', w-335, 110);
  text(' same plane - these will be the tires.', w-335, 140);
  text('3. Now add the carcass of the car. The top of it is', w-335, 170);
  text(' dome shape - like the Volkswagen Beetle.', w-335, 200);
  text('4. The car is driving towards your right side.', w-335, 230);
  text('5. Now add windows. There are two windows -', w-335, 260);
  text('one for the driver and the passanger.', w-335, 290);
  text('6. Now add doors. There are two doors and ', w-335, 320);
  text('two door handles.', w-335, 350);
  text('7. Color the car in the iconic Volkswagen', w-335, 380);
  text(' Beetle color.', w-335, 410);


}

  // <div class="column">
  //   <ul>
  //     <li>Now add windows. There are two windows - at the driver's seat and the passenger's side.</li>
  //     <li>Now add doors. There are two doors and two door handles.</li>
  //     <li>Color the car in the iconic Volkswagen Beetle color.</li>
  //   </ul>
  // </div>


// The different things I can measure and change

//Idle user
// if ((millis() - previousMillis) >= interval && pmouseX == mouseX){
//   background(255);
//   previousMillis = millis();
// }


// if the mouse is on the very bottom, ellipse loses saturation
// if (mouseY >=380){
// saturationcolor = saturation(colorPicker.value());
// colorvalue = saturationcolor;
//
// }else {
// colorvalue = colorPicker.value();
// }

// If the mouse is in the far right side, the stroke changes to black
// if (mouseX >=580){
//   stroke(46);
//   strokeValue = 46;
// } else {
//   strokeValue = colorvalue;
// }

//noise
//
// xoff = xoff + 0.03;
// let n = noise(xoff) * width;
// line(n, 0, n, height);
