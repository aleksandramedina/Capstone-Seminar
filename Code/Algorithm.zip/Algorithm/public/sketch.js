var socket;
var colorPicker;
var colorvalue;
var strokeValue;
var saturationcolor;
let stages = [0, 1, 2, 3, 4, 5, 6];
var xPoint;
var yPoint;
var ellipseHeight = 20;
var _instruction =0;
var interval = 5000;
var r;
var g;
var b;
var w = window.innerWidth;
var h = window.innerHeight;
var previousMillis = 0;
var xoff = 0.0;
var mode = 0;
var radius = 40;
var whichBuffer = 0;
var otherPos;
var prevOther;
var otherMode=0;
var isTriggered = false;
var isMouseDragged = false;
var ranColor = ('rgba(230,230,230,0.7)');
var inst =0;


function setup() {
  createCanvas(w,h);
  colorMode(RGB, 255);
  background (51);
  otherPos = createVector(0,0);
  prevOther = createVector(0,0);

  //eraser
  checkbox = createCheckbox('Eraser', false );
  checkbox.position(220, h-25);

  //slider for brush size
  slider = createSlider(5, 100, 30, 5);
  slider.position(320, h-25);

  //color picker
  colorPicker = createColorPicker(color('yellow'));
  colorPicker.position(30, h-30);

  socket = io.connect('http://localhost:3000')
  // socket = io.connect('http://d4043d164d4c.ngrok.io')
  socket.on('mouse', newDrawing);

}


function newDrawing(data){
  console.log("width: " + w);
  console.log("height: " + h);

  noStroke();
  fill(data.color);

// This is where the mirroring happens to the other canvas of what was
// drawn on canvas #1.

  if (data.instruction==0){
    ellipseHeight = data.slider;
    xPoint = data.x;
    yPoint = data.y;
    ellipse(xPoint, yPoint, data.slider, ellipseHeight);
  }
  else if (data.instruction==1){
    ellipseHeight = 1;
    xPoint = data.x;
    yPoint = data.y;
    ellipse(xPoint, yPoint, data.slider, ellipseHeight);
  }
  else if (data.instruction==2){
    ellipseHeight = data.slider;
    xPoint = data.y;
    yPoint = data.x;
    ellipse(xPoint, yPoint, data.slider, ellipseHeight);
  }else if (data.instruction==3){
    ellipseHeight = data.slider;
    xPoint = data.x;
    yPoint = data.y;
    ellipse(xPoint, yPoint, data.slider, ellipseHeight);
  }else if (data.instruction==4){
    ellipseHeight = data.slider;
    xPoint = data.x;
    yPoint = data.y;
    rect(xPoint, yPoint, data.slider, ellipseHeight);
  }else if (data.instruction==5){
    data.x = noise(frameCount * .001) * width;
    data.y = noise(frameCount * .003) * height;
      if (data.mode == 0) {
        push()
        stroke(255, 0, 0)
        rect(data.x, data.y, ellipseHeight, ellipseHeight);
        pop()
      }else if (data.mode == 1) {
        glitch(data.x, data.px, data.y, data.py)
      }
    data.px = data.x.copy();
  }else if (data.instruction==6){
    ellipseHeight = data.slider;
    xPoint = data.x;
    yPoint = data.y;
    ellipse(xPoint, yPoint, data.slider, ellipseHeight);
  }
}

function mouseDragged(){

// For debugging purposes.

  isMouseDragged = true;

// Preparing a data variable to send information from one user to the other.
  var data = {
    x: mouseX,
    y: mouseY,
    color: colorvalue,
    slider: slider.value(),
    instruction: _instruction,
    mode: mode,
    px: pmouseX,
    py: pmouseY
  }

socket.emit('mouse', data);

//Beginning of instructions
//Instruction 0: basic setting without any interruptions
//Instruction 1: ellipse height is set to 1 so the stroke becomes a inline
//Instruction 2: x and y axis are swapped
//Instruction 3: random color generator
//Instruction 4: stroke is a rectangle
//Instruction 5: Perlin noise glitch
//Instruction 6: color is changed to color(19,180,148)


//Instruction 0: basic setting without any interruptions
 if (data.instruction ==0){
   noStroke();

   if (checkbox.checked()){
     fill(51);
     colorvalue = 51;

   } else {
     fill(220);
     fill(colorPicker.value());
     colorvalue = colorPicker.value();
     console.log("Colorvalue: " + colorvalue);
   }

   ellipse(mouseX, mouseY, slider.value(), slider.value());
   ellipseHeight = slider.value();

//Instruction 1: ellipse height is set to 1 so the stroke becomes a inline
  }else if (data.instruction ==1){
     noStroke();

     if (checkbox.checked()){
       fill(51);
       colorvalue = 51;

     } else {
       fill(220);
       fill(colorPicker.value());
       colorvalue = colorPicker.value();
     }

     ellipseHeight=1;
     ellipse(mouseX, mouseY, slider.value(), ellipseHeight);

//Instruction 2: x and y axis are swapped
   }else if (data.instruction ==2){
     noStroke();

     if (checkbox.checked()){
       fill(51);
       colorvalue = 51;

      }else {
        fill(220);
        fill(colorPicker.value());
        colorvalue = colorPicker.value();
      }

      ellipse(mouseY, mouseX, slider.value(), slider.value());

//Instruction 3: random color generator
    }else if (data.instruction ==3){
      noStroke();

      if (checkbox.checked()){
        fill(51);
        colorvalue = 51;

      }else {
        colorvalue = color(random (255),random (255),random (255)).toString('#rrggbbaa');
        fill(colorvalue);

      }

      ellipse(mouseX, mouseY, slider.value(), slider.value());
      ellipseHeight = slider.value();

//Instruction 4: stroke is a rectangle
    } else if (data.instruction==4){
      noStroke();

      if (checkbox.checked()){
        fill(51);
        colorvalue = 51;

      }else {
        fill(220);
        fill(colorPicker.value());
        colorvalue = colorPicker.value();
      }

      rect(mouseX, mouseY, slider.value(), slider.value());
      ellipseHeight = slider.value();

//Instruction 5: Perlin noise glitch
    }else if (data.instruction==5){

      if (checkbox.checked()){
        fill(51);
        colorvalue = 51;

      }else {
        fill(220);
        fill(colorPicker.value());
        colorvalue = colorPicker.value();
      }
      ellipseHeight = slider.value();

      let glitchTime = map(millis(), 0, 10000, 0, 1);
      glitchTime = constrain(glitchTime, 0, 1);

      let rand = random();
      if (rand <= .1 && glitchTime > .5) {
        mode = 1;
      }else if (rand > .1 && rand <= .2 && glitchTime > .2) {
      }else {
        mode = 0;
      }

      // regular drawing mode
      if (mode == 0) {
        rect(mouseX, mouseY, ellipseHeight, ellipseHeight);
      }else if (mode == 1) {
        glitch(mouseX, pmouseX, mouseY, pmouseY)
      }
    }

//Instruction 6: color is changed to color(19,180,148)
  else if (data.instruction==6){
    noStroke();

    if (checkbox.checked()){
      fill(51);
      colorvalue = 51;

    }else {
      colorvalue = color(19,180,148).toString('#rrggbbaa');
      fill(colorvalue);
    }

    ellipse(mouseX, mouseY, slider.value(), slider.value());
    ellipseHeight = slider.value();

    } else {
       console.log("Other instruction found");
    }

} // end of  mouseDragged() and all instructions

// randomgenerator() is responsible for when the algorithm interrupts
// Every five seconds a number from 0 to six is generated, representing an instruction.
// The intruding instruction is being called for a duration of 1 second.
// While the algorithm is 'interrupting', the background is being changed as well.
// The time is being counted only while the mouse is being dragged; only when a user is interacting
// with the canvas.

function randomgenerator(){

    let s = second();
    console.log("s: " + s);

    if ((s%5==0 || s%5==1) && isMouseDragged == true){
      console.log("Mouse dragged: " + isMouseDragged);
      console.log("Is triggered: " + isTriggered);

      if (isTriggered == false){
        inst = random (stages);
        ranColor = color(random (255),random (255),random (255)).toString('#rrggbbaa');
        isMouseDragged = false;
        isTriggered = true;
      }
        fill(ranColor);
        _instruction = inst;
      }else {
        _instruction = 0;
        fill('rgba(230,230,230,0.7)');
        isTriggered = false;
      }

    // for debugging purposes
    console.log("Instruction: "+ _instruction);
}

//Allows the user to download a jpg of their work
function downloadWork(){
  saveCanvas('myDrawing', 'jpg');
  fill('yellow');
  textSize(20);
  textStyle(BOLD);
  text('Your work has been downloaded!', 400, 30);
}

//Clears the entire canvas.
function clearAll(){
  clear();
  background(51);
}

//The Perlin noise glitch function
function glitch(mx, px, my, py) {
  loadPixels();
  let dir = createVector(parseInt(mx) - parseInt(px), parseInt(my) - parseInt(py));
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      if (dist(x, y, parseInt(mx), parseInt(my)) < radius) {
        let d = pixelDensity();
        let oldX = x - dir.x;
        let oldY = y - dir.y;
        for (let i = 0; i < d; i++) {
          for (let j = 0; j < d; j++) {
            if (oldX > 0 && oldX < width && oldY > 0 && oldY < height) {
              let oldPixelIndex = 4 * ((oldY * d + j) * width * d + (oldX * d + i));
              let index = 4 * ((y * d + j) * width * d + (x * d + i));
              pixels[index] = pixels[oldPixelIndex];
              pixels[index + 1] = pixels[oldPixelIndex + 1];
              pixels[index + 2] = pixels[oldPixelIndex + 2];
            }
          }
        }
      }
    }
  }
  updatePixels();
}

//The draw function continuously calls the randomgenerator() function,
//and draws the instructions with the placeholder block.
function draw(){
  randomgenerator();

  noStroke();
  rect(0, h-45, w, 45);
  rect(w-350, 0, w, h);
  fill('black');
  textSize(16);
  text('Brush stroke', 460, h-17);
  text('Color picker', 100, h-17);

  textStyle(BOLD);
  text('Your task today: Draw a car', w-335, 30);

  textSize(14);
  textStyle(NORMAL);

  text('1. Pick a color that is good for sketching.', w-335, 80);
  text('2. Draw two circles next to each other on the', w-335, 110);
  text(' same plane - these will be the tires.', w-335, 140);
  text('3. Now add the frame of the car. The top of it is', w-335, 170);
  text(' dome shape - like the Volkswagen Beetle.', w-335, 200);
  text('4. The car is driving towards your right side.', w-335, 230);
  text('5. Now add windows. There are two windows -', w-335, 260);
  text('one for the driver and the passanger.', w-335, 290);
  text('6. Now add doors. There are two doors and ', w-335, 320);
  text('two door handles.', w-335, 350);
  text('7. Color the car in the iconic Volkswagen', w-335, 380);
  text(' Beetle color.', w-335, 410);

}
